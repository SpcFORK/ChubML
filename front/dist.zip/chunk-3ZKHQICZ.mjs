// src/cst.ts
var chaosGl = globalThis;
var chaosEval = chaosGl.eval;
var NOOP = () => {
};
var ANOOP = async () => {
};
var eo = new class cst {
  chaosGl = eobj_default(chaosGl, ["chaosGl"]).default;
  chaosEval = eobj_default(chaosEval, ["chaosEval"]).default;
  NOOP = eobj_default(NOOP, ["NOOP"]).default;
  ANOOP = eobj_default(ANOOP, ["ANOOP"]).default;
}();
var cst_default = eobj_default(eo).default;

// src/eobj.ts
var { chaosGl: chaosGl2 } = cst_default;
function eobj(obj, names = []) {
  if (!obj) throw new Error(`No object provided to eobj.`);
  if (!names.length && !!obj?.name)
    names.push(obj.name);
  names.push("default");
  let eo2 = {};
  for (const name of names)
    eo2[name] = obj;
  try {
    module.exports = eo2;
  } catch {
  }
  try {
    for (const name in names) chaosGl2.window[name] = obj;
  } catch {
  }
  return eo2;
}
var eobj_default = eobj(eobj).default;

export {
  eobj_default,
  cst_default
};
//# sourceMappingURL=chunk-3ZKHQICZ.mjs.map