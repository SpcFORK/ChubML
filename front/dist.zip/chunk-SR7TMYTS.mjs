if (globalThis.window) globalThis.module ||= { exports: {} }
import{b as n}from"./chunk-M46LSFT4.mjs";var t=class extends Error{constructor(r,o){super(Array.isArray(r)?r.join(`
`):r),this.name="CowErr"+(o?` (${o})`:"")}toss=(...r)=>console.error(this,...r);throw(){throw this}},e=n(t).default;export{e as a};
//# sourceMappingURL=chunk-SR7TMYTS.mjs.map