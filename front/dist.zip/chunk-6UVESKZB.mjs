if (globalThis.window) globalThis.module ||= { exports: {} }
import{a}from"./chunk-NCML6CQG.mjs";var o=globalThis,s=o.eval,l=()=>{},c=async()=>{},t=new class{chaosGl=a(o,["chaosGl"]).default;chaosEval=a(s,["chaosEval"]).default;NOOP=a(l,["NOOP"]).default;ANOOP=a(c,["ANOOP"]).default},f=a(t).default;export{f as a};
//# sourceMappingURL=chunk-6UVESKZB.mjs.map