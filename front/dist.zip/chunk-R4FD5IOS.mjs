import {
  eobj_default
} from "./chunk-RU6YNVQP.mjs";

// src/cst.ts
var chaosGl = globalThis;
var chaosEval = chaosGl.eval;
var NOOP = () => {
};
var ANOOP = async () => {
};
var eo = new class cst {
  chaosGl = eobj_default(chaosGl, ["chaosGl"]).default;
  chaosEval = eobj_default(chaosEval, ["chaosEval"]).default;
  NOOP = eobj_default(NOOP, ["NOOP"]).default;
  ANOOP = eobj_default(ANOOP, ["ANOOP"]).default;
}();
var cst_default = eobj_default(eo).default;

export {
  cst_default
};
//# sourceMappingURL=chunk-R4FD5IOS.mjs.map