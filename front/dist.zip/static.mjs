if (globalThis.window) globalThis.module ||= { exports: {} }
import{a}from"./chunk-KAUZXCCA.mjs";import"./chunk-NFLC73AM.mjs";import"./chunk-EH32PNJL.mjs";import"./chunk-XZQAGIEN.mjs";export{a as default};
//# sourceMappingURL=static.mjs.map