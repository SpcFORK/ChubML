if (globalThis.window) globalThis.module ||= { exports: {} }
import{a}from"./chunk-B2PTUXMD.mjs";import"./chunk-XZQAGIEN.mjs";export{a as default};
//# sourceMappingURL=domImp.mjs.map