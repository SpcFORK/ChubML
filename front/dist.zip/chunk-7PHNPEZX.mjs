if (globalThis.window) globalThis.module ||= { exports: {} }
import {
  eobj_default
} from "./chunk-L624HUU4.mjs";

// src/CowErr.ts
var CowErr = class extends Error {
  constructor(message, ext) {
    super(Array.isArray(message) ? message.join("\n") : message);
    this.name = "CowErr" + (ext ? ` (${ext})` : "");
  }
  toss = (...params) => console.error(this, ...params);
  throw() {
    throw this;
  }
};
var CowErr_default = eobj_default(CowErr).default;

export {
  CowErr_default
};
//# sourceMappingURL=chunk-7PHNPEZX.mjs.map