if (globalThis.window) globalThis.module ||= { exports: {} }
function r(e,t=[]){if(!e)throw new Error("No object provided to eobj.");e?.name&&t.push(e.name),t.push("default");let n={};for(let o of t){n[o]=e;try{window[o]=e}catch{}}try{module.exports=n}catch{}return n}var a=r(r).default;export{a};
//# sourceMappingURL=chunk-BMOIQQ53.mjs.map