if (globalThis.window) globalThis.module ||= { exports: {} }
import {
  cst_default
} from "./chunk-M6TBF2XG.mjs";
import {
  eobj_default
} from "./chunk-L624HUU4.mjs";

// src/CustomEventHandle.ts
var { chaosGl } = cst_default;
var CustomEventHandle = class {
  constructor(event) {
    this.event = event;
    this.#e = new this.#_E(event);
    this.#init();
  }
  #globalBus = [];
  #setHandle = (e) => {
    this.#globalBus.push(e);
  };
  #removeHandler = (e) => this.#globalBus.splice(this.#globalBus.indexOf(e), 1);
  #clearHandler = () => this.#globalBus = [];
  #addHandler = (e) => this.#globalBus.push(e);
  private = false;
  #getHandle = () => ({
    event: this.event,
    globals: this.#globalBus,
    remove: this.#removeHandler,
    clear: this.#clearHandler,
    add: this.#addHandler,
    _: () => !this.private ? this : null,
    [Symbol.toStringTag]: "CustomEventHandle"
  });
  #makeHandle = (name) => ({
    set: this.#setHandle,
    get: this.#getHandle
  });
  #activateGlobalSets = () => Object.defineProperty(chaosGl, this.event, this.#makeHandle(this.event));
  #init() {
    this.#activateGlobalSets();
  }
  get detail() {
    return Reflect.has(this.#e, "detail") ? this.#e.detail : null;
  }
  set detail(value) {
    this.makeEvent(this.event, value);
  }
  #e;
  #_E = globalThis.CustomEvent ? CustomEvent : Event;
  makeEvent(name, detail = {}) {
    return this.#e = new this.#_E(name, { detail });
  }
  activate() {
    for (const cb of this.#globalBus) cb(this.#e);
    dispatchEvent(this.#e);
  }
};
var CustomEventHandle_default = eobj_default(CustomEventHandle).default;

export {
  CustomEventHandle_default
};
//# sourceMappingURL=chunk-6XDCCZO2.mjs.map