/* 
�--- SpcFORK ---�
••¡¡¡¡••••ïï++••¡¡¡¡••••ïï++••¦¦¬¬||||¡¡¡¡¯¯¯¯ªª÷÷¯¯\\||{{••••••ïï••††\\¬¬¦¦¦¦}}
ïï++••¡¡¬¬{{••ïï++••¡¡¬¬{{••ïï++¡¡((¡¡¡¡¯¯¯¯ªªªª))))÷÷¯¯\\||||||{{ïï••††\\¬¬¦¦¦¦
{{••ïï++¬¬||||{{••ïï++¬¬||||{{••ïï¬¬¡¡¯¯¯¯ªªªª))))••ii))÷÷¯¯¯¯¯¯\\{{ïï••††\\¬¬¦¦
\\||{{••ïï((¡¡\\||{{••ïï((¡¡\\||{{••((¬¬ªªªª))))••••¬¬¬¬ii))))))÷÷\\{{ïï••††\\¬¬
¯¯¯¯\\||{{¬¬¡¡¯¯¯¯\\||{{¬¬¡¡¯¯¯¯\\||¬¬¡¡ªª))))••••¬¬¬¬¡¡\\¬¬¬¬¬¬ii÷÷\\{{ïï••††\\
¬¬ªª÷÷¯¯\\||((¬¬ªª÷÷¯¯\\||((¬¬ªª÷÷¯¯\\||¬¬””••••¬¬¬¬¡¡¡¡¦¦¦¦¦¦¦¦\\ii÷÷\\{{ïï••††
¡¡ªª))))÷÷¯¯\\¡¡ªª))))÷÷¯¯\\¡¡ªª))))÷÷¯¯¡¡ªª••¬¬¬¬¡¡¡¡¦¦¦¦cccc^^÷÷\\ii÷÷\\{{ïï••
||¬¬””••ii))÷÷¯¯¯¯””••ii))÷÷¯¯¯¯””••ii))÷÷¯¯””{{¡¡¡¡¦¦¦¦ccccÙÙcc^^÷÷\\ii÷÷\\{{ïï
¯¯¡¡ªª••¬¬¬¬ii))))))••¬¬¬¬ii))))))••¬¬¬¬ii))))••¡¡¦¦¦¦ccccÿÿÙÙÿÿcc^^÷÷\\ii÷÷\\{{
ªª÷÷¯¯””{{¡¡\\¬¬¬¬¬¬ii{{¡¡\\¬¬¬¬¬¬ii{{¡¡\\¬¬¬¬¬¬¬¬¬¬ccccððððÙÙññÙÙcc^^¦¦¬¬))¯¯||
ªª))))ªª••¡¡¦¦¦¦¦¦¦¦\\••¡¡¦¦¦¦¦¦¦¦\\¬¬¡¡¦¦¦¦¦¦¦¦¦¦¦¦¾¾ððððÙÙððÙÙññÙÙcc¦¦¬¬))¯¯||
))))••ii)){{¬¬cccc^^¦¦\\¬¬¬¬cccc^^¦¦¦¦¦¦¦¦cccc^^¦¦cccccccccccccccccccc¦¦¬¬))¯¯||
””••••¬¬¬¬••¡¡¾¾ððcc÷÷¦¦¦¦¦¦¾¾ððcc¦¦¬¬cccc¾¾ððcc÷÷¾¾ððððððððððððððððcc¦¦¬¬))¯¯||
ªª••¬¬¬¬¡¡\\¡¡¾¾ððccccccccccccððcc÷÷¦¦¾¾ððccððccccccððððððððððððððððcc¦¦¬¬))¯¯||
¬¬””{{¡¡¡¡¦¦¦¦¾¾ððððccððððccððððccccccccccccccccððððððððcc¾¾¾¾¾¾¾¾¾¾cc¦¦¬¬))¯¯||
¡¡ªª••¡¡¦¦¦¦ccccccððððððððððððcccc¾¾ððððððccððccððððððððcc¦¦¡¡¡¡¡¡¡¡¬¬¦¦\\ii÷÷\\
((¬¬””{{¬¬ccccððððððððððððððððððððccccccccccððccððððcc¾¾cc¦¦¬¬••••••{{¡¡¡¡¬¬))¯¯
¬¬¡¡ªª••¡¡¾¾ððcc¾¾ððccððððccððcc¾¾ððccððððccððccððððcccc^^¦¦\\¬¬¬¬ii””••{{¬¬ii÷÷
¡¡((¬¬””{{¬¬¾¾cc¦¦¾¾cccccccccccc^^ccccccððccððccððððððððcc÷÷¦¦¦¦¦¦\\iiªª””••••))
}}¡¡((¬¬””{{¡¡¬¬¦¦ccccððððcc¾¾ððccccððððccccððccððððððððcccccccc^^¦¦\\ii÷÷ªª””))
ïï}}¡¡((¬¬””••{{¬¬¾¾ððððððððccccððððccccððccððcc¾¾¾¾ððððððððððððcc÷÷¦¦\\ii÷÷¬¬ªª
//ïï}}¡¡((¬¬””••¡¡¾¾ððððððððccððccccððððccccððcc¦¦¾¾ððððððððððððcccc^^¦¦¬¬))¯¯¡¡
||++««¦¦¬¬¡¡ªª••¡¡ccccððððccccccððððccccððððcccc¦¦¬¬¾¾¾¾¾¾¾¾ððððððððcc¦¦¬¬))¯¯||
||++««¦¦¬¬¡¡ªª••¡¡¾¾ððððððððccððcc¾¾ððððcc¾¾cc¦¦÷÷¦¦¦¦¦¦¦¦¾¾ððððððððcc¦¦¬¬))¯¯||
¡¡//ïï}}¡¡((¬¬””{{¬¬¾¾¾¾cccccccccccc¾¾¾¾cc÷÷¦¦÷÷¦¦cccc^^cccc¾¾¾¾ððððcc¦¦¬¬))¯¯||
««¡¡//ïï}}¡¡((¬¬””{{¡¡¬¬¾¾ððccððccððcc÷÷¦¦cccccc^^¾¾ððcc¾¾ððcc¾¾ððððcc¦¦¬¬))¯¯||
ii««¡¡//ïï}}¡¡((¬¬””{{¡¡¾¾ððccððccððcccc^^¾¾ððððcccc¾¾cccc¾¾cc¾¾ððððcc¦¦¬¬))¯¯||
))¡¡÷÷||++««¦¦¬¬¡¡ªª••¡¡¾¾ððccððððððððððcc¾¾ððððccððccccððccccccððððcc¦¦¬¬))¯¯||
))¡¡÷÷||++««¦¦¬¬¡¡ªª••¡¡¾¾ððccððcccccccccc¾¾ððððcc¾¾ððððccccððððððððcc¦¦¬¬))¯¯||
))¡¡÷÷||++««¦¦¬¬¡¡ªª••¡¡¾¾ððccððððððððððcc¾¾ððððccccccccccccððððððððcc¦¦¬¬))¯¯||
))¡¡÷÷||++««¦¦¬¬¡¡ªª••¡¡¾¾ððcccccccccccccc¦¦¾¾¾¾ððððððððððððððððcc¾¾cc¦¦¬¬))¯¯||
))¡¡÷÷||++««¦¦¬¬¡¡ªª••¡¡¾¾ððððððððððððððcc¦¦¬¬¾¾ððððððððððððððððcc¦¦¬¬¦¦\\ii÷÷\\
ïïii««¡¡//ïï}}¡¡((¬¬””{{¬¬¾¾¾¾¾¾¾¾¾¾¾¾¾¾cc¦¦¬¬¬¬¾¾¾¾¾¾¾¾¾¾¾¾¾¾¾¾cc¦¦¬¬¡¡¡¡¬¬))¯¯
——ïïii««¡¡//ïï}}¡¡((¬¬””{{¡¡¡¡¡¡¡¡¡¡¡¡¡¡¬¬¦¦\\{{¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¡¬¬¦¦\\••{{¬¬ii÷÷
————ïïii««¡¡//ïï}}¡¡((¬¬””••••••••••••••{{¡¡¡¡¬¬••••••••••••••••{{¡¡¡¡¬¬))••••))
——————ïïii««¡¡//ïï}}¡¡((¬¬ªªªªªªªªªªªªªª””••{{¬¬iiªªªªªªªªªªªªªª””••{{¬¬iiªª””))
————————ïïii««¡¡//ïï}}¡¡((¡¡¡¡¡¡¡¡¡¡¡¡¡¡¬¬ªª””••••))¯¯¡¡¡¡¡¡¡¡¡¡¬¬ªª””••••))¯¯ªª
——————————ïïii««¡¡//ïï}}¡¡¬¬¬¬¬¬¬¬¬¬¬¬¬¬((¡¡¬¬ªª””))÷÷\\¬¬¬¬¬¬¬¬((¡¡¬¬ªª””))÷÷¡¡
————————————ïïii««¡¡//ïï}}¦¦¦¦¦¦¦¦¦¦¦¦¦¦¡¡¬¬((¡¡¬¬ªªªª¯¯||••++¦¦¡¡¬¬((¡¡¬¬ªªªª¯¯
——————————————ïïii««¡¡//ïï««««««««««««««}}¦¦¡¡¬¬((¡¡¬¬¯¯\\{{ïï••}}¦¦¡¡¬¬((¡¡¬¬¯¯
�--- SpcFORK ---�
*/
if (globalThis.window) globalThis.module ||= { exports: {} }
import{b as o}from"./chunk-KWHYKVIM.mjs";var c=class r{constructor(e,t=e.documentElement){this.document=e;this.documentElement=t}args=[];init(...e){this.document.open(...this.args),this.document.write(...e),this.document.close()}initScripts(e=this.document){let t=Array.from(e.scripts);return t.forEach(n=>{let i=document.createElement("script");for(let l of n.attributes)i.setAttribute(l.name,l.value);i.textContent=n.textContent,document.body.appendChild(i)}),t}static d=globalThis.document?.implementation;static makeStaticPage=function(e){if(!r.d)throw new Error("No document implementation");let t=r.d.createHTMLDocument(e);return new r(t)};static writePageToPage(e){let t=e.document.documentElement;document.documentElement.replaceWith(t)}static manualWrite=function(...e){let t;new.target&&([t,...e]=e);let n=r.makeStaticPage(t);return n.init(...e),n.initScripts(),r.writePageToPage(n),n}},a=class r{static d=globalThis.document?.implementation;static makeDoc(e,t,n){if(!this.d)throw new Error("No document implementation");let i=this.d.createDocument(e,t,n);return new r(i)}document;constructor(e){this.document=e}addElement(e,t={}){let n=this.document.createElement(e);for(let i in t)n.setAttribute(i,t[i]);return this.document.appendChild(n),n}getElementsByTagName(e){return this.document.getElementsByTagName(e)}serialize(){return new XMLSerializer().serializeToString(this.document)}treewalk(e,t=NodeFilter.SHOW_ALL){let n=document.createTreeWalker(this.document,t),i;for(;i=n.nextNode();)e(i,n)}},d={CowHTMLDocCtx:o(c).default,CowXMLDocCtx:o(a).default};export{d as a};
//# sourceMappingURL=chunk-UKOXJSTV.mjs.map