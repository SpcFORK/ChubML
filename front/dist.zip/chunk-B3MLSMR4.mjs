if (globalThis.window) globalThis.module ||= { exports: {} }
import {
  eobj_default
} from "./chunk-TLMDWOGW.mjs";

// src/cst.ts
var chaosGl = globalThis;
var chaosEval = chaosGl.eval;
var NOOP = () => {
};
var ANOOP = async () => {
};
var eo = new class cst {
  chaosGl = eobj_default(chaosGl, ["chaosGl"]).default;
  chaosEval = eobj_default(chaosEval, ["chaosEval"]).default;
  NOOP = eobj_default(NOOP, ["NOOP"]).default;
  ANOOP = eobj_default(ANOOP, ["ANOOP"]).default;
}();
var cst_default = eobj_default(eo).default;

export {
  cst_default
};
//# sourceMappingURL=chunk-B3MLSMR4.mjs.map