declare const _default: {
    chaosGl: any;
    chaosEval: any;
    NOOP: () => any;
    ANOOP: () => Promise<any>;
    R: NodeRequire;
};

export { _default as default };
