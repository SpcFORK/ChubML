if (globalThis.window) globalThis.module ||= { exports: {} }
import{a}from"./chunk-QRTXHO3S.mjs";import"./chunk-EH32PNJL.mjs";import"./chunk-XZQAGIEN.mjs";export{a as default};
//# sourceMappingURL=CustomEventHandle.mjs.map