interface CILElement {
    c: string;
    i: string | number;
}
interface ChubNode {
    tag: string;
    id: string;
    class: string;
    content: string;
    data: string;
    style: string;
    attr: string;
    indent: number;
    [Symbol.unscopables]: {
        _: SortedCILE | null;
        atBucket: string[];
        data: Record<any, any>;
    };
}
interface SortedCILE extends CILElement {
    parent: SortedCILE | null;
    children: SortedCILE[];
    o?: ChubNode;
}
declare type CILEList = CILElement[];
declare type SortedCIL = SortedCILE[];

export type { CILEList, ChubNode, SortedCIL, SortedCILE };
