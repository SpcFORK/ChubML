declare class CowObj {
    SJSON(): string;
    toJSON(): this & {
        __methods: Record<string, string>;
    };
    private extractMethods;
}
declare const _default: typeof CowObj;

declare type CowObject<Object = {}> = Object & Partial<{
    __methods: Record<string, string>;
}>;

export { type CowObject, _default as default };
