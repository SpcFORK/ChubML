import _default$1 from './static.mjs';

/**
 * A ChubML instance.
 *
 * =-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-
 *
 * 2024
 * SpcFORK - ChubML
 * Copyright (c) SpcFORK
 *
 * =-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-
 *
 * ```go
 *       ,""""""""""""""""",^,"""""""""""",
 *     .l ?]]]]]]]]]]]]]]]].~.????????????.I
 *     ",!l]IIIIIIIIIIIIIIII,< ]]]]]]]]]]]] l
 *     l ]]]lllllllllllllIII:> ]]]]]]]]]]]] l
 *     l:iii>>>>>>>>>>>>>]]] ~ ]]]]]]]]]]]] l
 *     l`++++++++++++++++---.~ ]]]]]]]]]]]] l
 *     lIIIIIIIIIIIIIIIIIIII;~.??????----?? l
 *     lIlllllllllllllllllll:iI"""""",;:;''l;".
 *     l;lllllllllllllllllll:l    '^,,Iii??]-i;".
 *     `I,I:::::::::I,,,,,,,:`   ,;ii??]]]]]]]-i",
 *      ,:iiiiiiiii:,          :IIii!!!!!!!?]]]I:"
 *      l ]]]]]]]]] l           ^`````````l.]]]] i
 *      l ]]]]]]]]] l                   .`l.]]]]?.I
 *      l.?]]]]]]]] l         ,""""""""";!!?]]]]] l
 *      `i ]]]]]]]] l        I.?????????-]]]]]]]I";
 *       ;:I]]]]]]]l;""""""",! ]]]]]]]]]]]]]]]?!^;
 *        I,i-]]]]]]-???????.~ ]]]]]]]]]]]]]?!,,^
 *         ^IIi?-]]]]]]]]]]] ~ ]]]]]]]]]]??!,,^
 *           ^I"I!!!!!!!!!!!">:!!!!!!!!!!,",^
 *              ^```````````^ ^``````````^
 * ```
 *
 * =-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-
 *
 * TODO:
 * - Make code cleaner/compact.
 * - Make ECSS.

 * - Implement CowStack !!

 * - Create CHUBECSS Parser.
 *
 * =-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-
 *
 * TOUR:
 *   *Q-Sel:
 *   $()
 *   *Array matcher
 *       arrMatch
 *   *Parser:
 *     parse()
 *       -> sortInd()
 *       -> stringi()
 *
 * =-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=--=-=-=-=-
*/
declare class ChubMLMod extends _default$1 {
    #private;
    static ChubML: typeof ChubMLMod;
    ChubML: typeof ChubMLMod;
    static handleLiveReload(el: Element): Promise<void>;
    handleLiveReload: typeof ChubMLMod.handleLiveReload;
    static _(scope: {
        [key: string]: any;
        [Symbol.unscopables]: any;
    }): Record<string, any>;
    un: typeof ChubMLMod._;
    static _b(scope: {
        [key: string]: any;
        [Symbol.unscopables]: any;
    }): string[];
    ab: typeof ChubMLMod._b;
    static _d(scope: {
        [key: string]: any;
        [Symbol.unscopables]: any;
    }): Record<any, any>;
    dt: typeof ChubMLMod._d;
    static get __lastQM(): any;
    static set __lastQM(val: any);
    get __lastQM(): any;
    set __lastQM(val: any);
    static get __lastQD(): any;
    static set __lastQD(val: any);
    get __lastQD(): any;
    set __lastQD(val: any);
    get doc(): Document;
    get body(): HTMLElement;
    set body(val: HTMLElement);
    get head(): HTMLHeadElement;
    set head(val: HTMLHeadElement);
    get html(): HTMLElement;
    get title(): string;
    set title(val: string);
    get chubLocation(): string;
    set chubLocation(val: string);
    get chubDev(): boolean;
    set chubDev(val: boolean);
    s: {
        new (): {
            CML_Static: any;
            $<T extends Element>(a: string): T | null;
            arrMatch(str: string | any[], arr: string | any[]): {
                count: number;
                list: any[];
            };
        };
        CML_Static: any;
        errorList: {
            eqspl3: {
                toss: (...params: any[]) => void;
                throw(): void;
                name: string;
                message: string;
                stack?: string | undefined;
                cause?: unknown;
            };
            scripterror: {
                toss: (...params: any[]) => void;
                throw(): void;
                name: string;
                message: string;
                stack?: string | undefined;
                cause?: unknown;
            };
        };
        DisplayErrors: {
            noBeam: string;
        };
        Rexps: {
            quoteExept: RegExp;
            colExept: RegExp;
            betweenQuote: RegExp;
            betweenCol: RegExp;
            script: RegExp;
            comment: RegExp;
            lineWithComment: RegExp;
            formatspace1: RegExp;
            formatspace2: RegExp;
        };
    };
    styled: Record<string, any>;
    promiseBucket: Promise<any>[];
    parse(source: string, lessNl?: boolean | undefined): string;
    findFile(fileLocations: any): Promise<any>;
    ChubRep(doc: string, quirky?: string): {
        document: Document;
        documentElement: HTMLElement;
        args: never[];
        init(...html: string[]): void;
        initScripts(element?: Document): HTMLScriptElement[];
    };
    injectChub(input: string): void;
    Router: {
        new (): {
            __env__: string;
        };
    };
    CHUBfax(tex: string, sep?: string): string;
    attrSyn(tex: string): string[];
    /**
     * Fetch a web page and convert it to CHUB
     * @param {string} url The URL of the web page to fetch
     * @returns The CHUB representation of the web page
     */
    CHUBWFetch(url: string | URL | Request): Promise<string>;
    getURLbit(): string;
    CHUBsanitize(input: string): string;
    DupeCollection: Record<string, any>;
    /**
     * @param {string} dupe - The dupe to be added to the collection.
     * @returns {object} - The edited dupe, the dupe collection, and the stringified and parsed collection.
     */
    CHUBduper(dupe?: string): object;
    CHUBstrprep(str: string): string;
    CHUBunmess(str: string): any[];
    MLTextToNodes(str: string, type?: DOMParserSupportedType): Document;
    Chubify(str: string): Document;
    HTMLToChub: (html: string | Element, delim?: string) => string;
    getChubML: (node: Element, indent?: string, delim?: string) => string;
    aliasIndexes: string[];
    beamPrep(location: string | URL | Request, slowly: boolean): Promise<{
        location: string | URL | Request;
        req: Response;
        okRes: Response;
    }>;
    beamParse(req: Response, location?: any): Promise<{
        text: string;
        doc: string;
        location: any;
    }>;
    beamMake(location: string | URL | Request, slowly: boolean): Promise<{
        text: string;
        doc: string;
        location: any;
    }>;
    beamDo(req: Response, DOM: any): Promise<void>;
    beamRender(doc: string, DOM: any, optionalDetails?: {}): void;
    beamSync(location: string | URL | Request, DOM: any, slowly?: boolean): Promise<() => Promise<void>>;
    /**
     * Example usage:
     *
     * ```typescript
     * const cml = new ChubMLMod();
     * cml.beamChub('/path/to/chub/file', document.getElementById('app'), true);
     * ```
     *
     * @param slowly - If true, errors are ignored and execution using a quicker Promise.all, this is better for users, worse for servers.
     */
    beamChub(location: string | URL | Request, DOM: any, slowly?: boolean): Promise<void>;
    constructor();
}
declare const _default: ChubMLMod;

export { _default as default };
