if (globalThis.window) globalThis.module ||= { exports: {} }
"use strict";
//# sourceMappingURL=exp.js.map