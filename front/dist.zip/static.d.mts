declare class CML_Static {
    static CML_Static: typeof CML_Static;
    CML_Static: typeof CML_Static;
    static errorList: {
        eqspl3: {
            toss: (...params: any[]) => void;
            throw(): void;
            name: string;
            message: string;
            stack?: string | undefined;
            cause?: unknown;
        };
        scripterror: {
            toss: (...params: any[]) => void;
            throw(): void;
            name: string;
            message: string;
            stack?: string | undefined;
            cause?: unknown;
        };
    };
    static DisplayErrors: {
        noBeam: string;
    };
    static Rexps: {
        quoteExept: RegExp;
        colExept: RegExp;
        betweenQuote: RegExp;
        betweenCol: RegExp;
        script: RegExp;
        comment: RegExp;
        lineWithComment: RegExp;
        formatspace1: RegExp;
        formatspace2: RegExp;
    };
    $<T extends Element>(a: string): T | null;
    arrMatch(str: string | any[], arr: string | any[]): {
        count: number;
        list: any[];
    };
}
declare const _default: typeof CML_Static;

export { _default as default };
