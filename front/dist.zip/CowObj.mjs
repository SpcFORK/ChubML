if (globalThis.window) globalThis.module ||= { exports: {} }
import{b as s}from"./chunk-XZQAGIEN.mjs";var e=class{SJSON(){return JSON.stringify(this)}toJSON(){return{...this,__methods:this.extractMethods()}}extractMethods(){let r={};for(let t in this)typeof this[t]=="function"&&(r[t]=String(this[t]));return r}},n=s(e).default;export{n as default};
//# sourceMappingURL=CowObj.mjs.map