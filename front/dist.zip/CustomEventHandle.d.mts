declare class CustomEventHandle {
    #private;
    event: string;
    private: boolean;
    get detail(): any;
    set detail(value: any);
    makeEvent(name: string, detail?: {
        detail?: unknown;
    } & Record<string, unknown>): Event;
    activate(): void;
    constructor(event: string);
}
declare const _default: typeof CustomEventHandle;

export { _default as default };
