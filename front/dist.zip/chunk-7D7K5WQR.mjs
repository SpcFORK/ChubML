var t=class extends Error{constructor(r,n){super(Array.isArray(r)?r.join(`
`):r),this.name="CowErr"+(n?` (${n})`:"")}toss=(...r)=>console.error(this,...r);throw(){throw this}};export{t as a};
//# sourceMappingURL=chunk-7D7K5WQR.mjs.map