if (globalThis.window) globalThis.module ||= { exports: {} }
import{a}from"./chunk-NFLC73AM.mjs";import"./chunk-XZQAGIEN.mjs";export{a as default};
//# sourceMappingURL=CowErr.mjs.map