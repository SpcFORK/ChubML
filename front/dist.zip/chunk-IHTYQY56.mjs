if (globalThis.window) globalThis.module ||= { exports: {} }
import{a as n}from"./chunk-I4BSH2R5.mjs";var t=class extends Error{constructor(r,o){super(Array.isArray(r)?r.join(`
`):r),this.name="CowErr"+(o?` (${o})`:"")}toss=(...r)=>console.error(this,...r);throw(){throw this}},e=n(t).default;export{e as a};
//# sourceMappingURL=chunk-IHTYQY56.mjs.map