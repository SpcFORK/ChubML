import {
  cst_default
} from "./chunk-4ZPTQZP2.mjs";

// src/checkEnvironment.ts
var { chaosEval } = cst_default;
var checkEnvironment = () => {
  let isImportSupported = false;
  try {
    chaosEval("import.meta");
    isImportSupported = true;
  } catch {
  }
  if (isImportSupported) {
    return "ES Module";
  } else if (typeof module !== "undefined" && module?.exports && typeof window === "undefined") {
    return "Node";
  } else if (typeof window !== "undefined" && typeof window?.document !== "undefined") {
    return "Browser";
  } else {
    return "Unknown";
  }
};

export {
  checkEnvironment
};
//# sourceMappingURL=chunk-OPVFJD2N.mjs.map