if (globalThis.window) globalThis.module ||= { exports: {} }
//# sourceMappingURL=exp.mjs.map