if (globalThis.window) globalThis.module ||= { exports: {} }
import{b as n}from"./chunk-XZQAGIEN.mjs";var t=class extends Error{constructor(r,o){super(Array.isArray(r)?r.join(`
`):r),this.name="CowErr"+(o?` (${o})`:"")}toss=(...r)=>console.error(this,...r);throw(){throw this}},e=n(t).default;export{e as a};
//# sourceMappingURL=chunk-NFLC73AM.mjs.map