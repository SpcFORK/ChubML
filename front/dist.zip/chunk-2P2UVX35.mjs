if (globalThis.window) globalThis.module ||= { exports: {} }
import{a as n}from"./chunk-NCML6CQG.mjs";var t=class extends Error{constructor(r,o){super(Array.isArray(r)?r.join(`
`):r),this.name="CowErr"+(o?` (${o})`:"")}toss=(...r)=>console.error(this,...r);throw(){throw this}},e=n(t).default;export{e as a};
//# sourceMappingURL=chunk-2P2UVX35.mjs.map