import {
  eobj_default
} from "./chunk-GVROHRPC.mjs";

// src/CowErr.ts
var CowErr = class extends Error {
  constructor(message, ext) {
    super(Array.isArray(message) ? message.join("\n") : message);
    this.name = "CowErr" + (ext ? ` (${ext})` : "");
  }
  toss = (...params) => console.error(this, ...params);
  throw() {
    throw this;
  }
};
var CowErr_default = eobj_default(CowErr).default;

export {
  CowErr_default
};
//# sourceMappingURL=chunk-JMBXWI4B.mjs.map