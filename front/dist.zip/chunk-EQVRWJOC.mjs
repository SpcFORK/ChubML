// src/eobj.ts
if (globalThis.window)
  globalThis.module ||= { exports: {} };
function eobj(obj, names = []) {
  if (!obj) throw new Error(`No object provided to eobj.`);
  if (!names.length && !!obj?.name)
    names.push(obj.name);
  names.push("default");
  let eo = {};
  for (const name of names)
    eo[name] = obj;
  try {
    module.exports = eo;
  } catch {
  }
  try {
    for (const name in names) globalThis.window[name] = obj;
  } catch {
  }
  return eo;
}
var eobj_default = eobj(eobj).default;

export {
  eobj_default
};
//# sourceMappingURL=chunk-EQVRWJOC.mjs.map