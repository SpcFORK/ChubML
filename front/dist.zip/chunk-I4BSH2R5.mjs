if (globalThis.window) globalThis.module ||= { exports: {} }
function r(e,t=[]){if(!e)throw new Error("No object provided to eobj.");e?.name&&t.push(e.name),t.push("default");let o={};for(let n of t){o[n]=e;try{window[n]=e}catch{}}try{module.exports=o}catch{}return o}var a=r(r,["eobj"]).default;export{a};
//# sourceMappingURL=chunk-I4BSH2R5.mjs.map