var o=globalThis,a=o.eval,s=()=>{},n=async()=>{};export{o as a,a as b,s as c,n as d};
//# sourceMappingURL=chunk-5FZSLDQI.mjs.map