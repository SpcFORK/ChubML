declare class CowErr extends Error {
    constructor(message: string | (string | undefined)[], ext?: string);
    toss: (...params: any[]) => void;
    throw(): void;
}
declare const _default: typeof CowErr;

export { _default as default };
