if (globalThis.window) globalThis.module ||= { exports: {} }
import{b as a}from"./chunk-XZQAGIEN.mjs";export{a as default};
//# sourceMappingURL=eobj.mjs.map