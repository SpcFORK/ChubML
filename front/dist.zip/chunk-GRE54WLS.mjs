import {
  cst_default
} from "./chunk-7UEZNBXO.mjs";
import {
  eobj_default
} from "./chunk-GVROHRPC.mjs";

// src/checkEnvironment.ts
var { chaosEval } = cst_default;
var checkEnvironment = () => {
  let isImportSupported = false;
  try {
    chaosEval("import.meta");
    isImportSupported = true;
  } catch {
  }
  if (isImportSupported) {
    return "ES Module";
  } else if (typeof module !== "undefined" && module?.exports && typeof window === "undefined") {
    return "Node";
  } else if (typeof window !== "undefined" && typeof window?.document !== "undefined") {
    return "Browser";
  } else {
    return "Unknown";
  }
};
var checkEnvironment_default = eobj_default(checkEnvironment, ["checkEnvironment"]).default;

export {
  checkEnvironment_default
};
//# sourceMappingURL=chunk-GRE54WLS.mjs.map