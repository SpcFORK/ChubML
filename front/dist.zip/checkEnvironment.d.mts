declare const _default: () => "ES Module" | "Node" | "Browser" | "Unknown";

export { _default as default };
