if (globalThis.window) globalThis.module ||= { exports: {} }
import{a}from"./chunk-EJTNPTUO.mjs";import"./chunk-EH32PNJL.mjs";import"./chunk-XZQAGIEN.mjs";export{a as default};
//# sourceMappingURL=checkEnvironment.mjs.map